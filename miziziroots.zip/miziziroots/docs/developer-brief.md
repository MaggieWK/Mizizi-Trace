# Mizizi Trace — Developer Brief

*Redefining who controls value creation.*

## What this is

Mizizi Trace is a working prototype (single HTML file, no backend) that generates audience-specific impact and export-compliance reports — for farmers, consumers, procurement/distributor buyers, and investor/stakeholder audiences — across multiple commodities and destination markets (EU/EUDR and Gulf/halal-traceability). The prototype is fully functional and demonstrates the intended product; it currently runs entirely in the browser with no persistence, no real data connections, and no backend.

We need a developer to take it from a working demo to a small, real, maintainable tool — without a full platform rebuild.

## The four tasks

| Task | What it means | Rough effort |
|---|---|---|
| **1. Connect config lists to a spreadsheet** | Replace the hardcoded commodity/market/document lists in `index.html` with live reads from an Airtable base or Google Sheet (see `config/` for the target shape), so non-developers can add/edit rows without touching code. | 2–4 days |
| **2. Add persistence** | Store farmer/order/delivery records somewhere real (Airtable, Google Sheets, or a small database) instead of the in-browser mock data that resets on refresh. | 3–5 days |
| **3. Real email capture** | Replace the current front-end-only email gate with an actual Klaviyo signup form embed, so captured emails land in our Klaviyo account. | 0.5–1 day |
| **4. Live emission-factor source** | Connect the climate calculations to a maintained emission-factor source (e.g. EPA GHG Emission Factors Hub, DEFRA) instead of fixed constants in the code. | 2–3 days |

## What we can provide

- The existing prototype (`index.html` — vanilla JS, no framework).
- Config templates already structured to match the tool's internal data (`config/commodities.csv`, `config/markets.csv`, `config/export_documents.csv`, `config/origin_sites.csv`), ready to import into Airtable or Google Sheets.
- A Klaviyo account for the email-capture integration.

## What we're looking for

- Comfortable with a small, pragmatic scope — this should stay a lightweight tool, not become a large platform rebuild.
- Experience connecting a front-end to Airtable/Google Sheets as a lightweight data source (no need for a custom database at this stage).
- Clear communication in plain language — we are not a technical team and need to understand tradeoffs, not just receive finished code.

## Format

Open to a fixed-price quote per task above, or a small time-boxed engagement (e.g. one week) covering tasks 1–3 first, with task 4 as a follow-on once the first three are working.
